// Pure report mapping; mirrors the two sheets in otraining's public export UI.
export const MediaExportModel=(()=>{
 const clean=v=>String(v??'').trim(),record=v=>v&&typeof v==='object'&&!Array.isArray(v);
 const code=v=>clean(v).replace(/\.0+$/,'').toUpperCase().replace(/^0+(?=\d+$)/,'');
 const norm=v=>clean(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[Đđ]/g,'d').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
 const numeric=v=>v!==null&&v!==undefined&&v!==''&&Number.isFinite(Number(v))&&Number(v)>=0?Number(v):'';
 const similarity=(a,b)=>{a=norm(a);b=norm(b);if(!a||!b)return 0;if(a===b)return 1;if(a.includes(b)||b.includes(a))return .95;const x=new Set(a.split(' ')),y=new Set(b.split(' '));return [...x].filter(t=>y.has(t)).length/Math.max(x.size,y.size);};
 function program(e,camp){
  const ps=e.programs;if(!Array.isArray(ps))throw Error('missing programs');
  if(clean(camp.programId)){
   const found=ps.filter(p=>clean(p.program_id??p.programId)===clean(camp.programId));if(found.length>1)throw Error('duplicate program');
   if(found.length)return found[0];
   if((camp.mediaCampaignType||'noibo')==='noibo'&&ps.every(p=>p.program_id==null&&p.programId==null))return ps[Number(camp.programId)-1]||null;
   return null;
  }
  const ranked=ps.map(p=>({p,s:similarity(p.program_name??p.name,camp.name)})).filter(x=>x.s>=.9).sort((a,b)=>b.s-a.s);
  if(ranked.length>1&&ranked[0].s===ranked[1].s)throw Error('ambiguous program');return ranked[0]?.p||null;
 }
 function normalize(source,camp,roster){
  if(source?.success===false||source?.ok===false)throw Error('source failure');
  const employees=Array.isArray(source)?source:source?.employees??source?.data??source?.rows;
  if(!Array.isArray(employees)||!employees.length||employees.some(e=>!record(e)||!Array.isArray(e.programs)))throw Error('missing employees');
  if(numeric(source.total)!==''&&Number(source.total)>employees.length)throw Error('partial source');
  const wanted=new Set(roster.map(p=>code(p.code))),byCode=new Map();
  for(const e of employees){const key=code(e.employee_code??e.code);if(!wanted.has(key))continue;if(byCode.has(key))throw Error('duplicate source employee');byCode.set(key,e);}
  const selected=roster.map(pg=>{const e=byCode.get(code(pg.code));return {pg,e,p:e?program(e,camp):null};});
  if(!employees.some(e=>program(e,camp)))throw Error('missing selected program');
  const titles=new Set(selected.filter(x=>x.p).map(x=>clean(x.p.program_name??x.p.name)).filter(Boolean));
  if(titles.size>1)throw Error('inconsistent program name');const title=[...titles][0]||clean(camp.name);
  const columns=['Mã NV','Tên nhân viên','Vùng','Khu vực','Đã duyệt FB','Bị loại FB','Đã duyệt TT','Bị loại TT',...['Nộp','Đúng','Target','Tỷ lệ (%)'].map(k=>title+' - '+k)];
  const detailColumns=['Mã NV','Tên nhân viên','Vùng','Khu vực','Tên chương trình','Platform','Link','Trạng thái','View','Tim/Like','Comment','Share','Favorite'];
  const rows=[],links=[];let missingEmployees=0,missingPrograms=0;
  for(const {pg,e,p} of selected){
   // Dashboard roster supplies identity/ownership; never trust an upstream area to grant access.
   const base=[clean(pg.code),clean(pg.name)||clean(e?.full_name??e?.name),clean(e?.vung),clean(pg.region)];
   if(!e)missingEmployees++;else if(!p)missingPrograms++;
   rows.push([...base,...['facebook_count','facebook_rejected_count','tiktok_count','tiktok_rejected_count'].map(k=>numeric(e?.[k])),...['submitted','approved','target','completion_pct'].map(k=>numeric(p?.[k]))]);
   if(!p)continue;
   if(!Array.isArray(p.links)&&numeric(p.submitted)!==0)throw Error('missing link details');
   if(numeric(p.submitted)>0&&Array.isArray(p.links)&&!p.links.length)throw Error('missing submitted links');
   for(const link of (p.links||[])){
    if(!record(link))throw Error('invalid link');
    links.push([...base,clean(p.program_name??p.name),clean(link.platform),clean(link.url),clean(link.status),...['view_count','reaction_count','comment_count','share_count','favorite_count'].map(k=>numeric(link[k]))]);
   }
  }
  return {pgCount:rows.length,linkCount:links.length,warnings:{missingEmployees,missingPrograms},sheets:[{name:'TienDoTruyenThong',columns,rows},{name:'ChiTietLink',columns:detailColumns,rows:links}]};
 }
 return {clean,record,code,norm,numeric,normalize};
})();
