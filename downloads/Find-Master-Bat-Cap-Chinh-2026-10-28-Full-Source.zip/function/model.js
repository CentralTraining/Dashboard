export const PairModel=(()=>{
 const stages=['m1','m2','m3','m4','m5'];
 const code=v=>String(v??'').trim().replace(/\.0+$/,'').toUpperCase();
 const norm=v=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[Đđ]/g,'d').toLowerCase().replace(/[^a-z0-9]/g,'');
 const flag=v=>v===true||v===1||v==='1'||v==='true'||v==='TRUE'?true:v===false||v===0||v==='0'||v==='false'||v==='FALSE'?false:null;
 const firstName=v=>String(v||'').trim().split(/\s+/).at(-1)||'Chưa có tên';
 function roster(registered,meta,trainer){
  const map=new Map(),ambiguous=new Set();
  for(const p of registered||[]){
   if(String(p.trainerId)!==String(trainer.id)||p.region&&norm(p.region)!==norm(trainer.region))continue;
   const id=code(p.code);if(!id)continue;
   if(map.has(id)){ambiguous.add(id);continue;}
   const source=meta?.[id],fromSystem=source?.source==='OTRAINING FM';
   const progress=Object.fromEntries(stages.map(stage=>{const value=fromSystem?flag(source.done?.[stage]):null;return [stage,{done:value===true,known:value!==null}];}));
   map.set(id,{code:id,name:String(p.name||'').trim(),channel:String(p.channel||'').trim(),trainerId:String(trainer.id),region:String(trainer.region||p.region||''),progress});
  }
  ambiguous.forEach(id=>map.delete(id));
  return [...map.values()].sort((a,b)=>a.code.localeCompare(b.code));
 }
 function group(raw,roster,ownerId){
  const byCode=new Map(roster.map(p=>[p.code,p])),members=(raw.members||[]).map(id=>byCode.get(code(id))||{code:code(id),name:'PG không còn trong danh sách',channel:'',missing:true,progress:{}});
  const valid=[2,3].includes(members.length)&&(members.length!==3||roster.length%2===1)&&new Set(members.map(p=>p.code)).size===members.length&&members.every(p=>!p.missing&&p.trainerId===String(ownerId));
  const progress=Object.fromEntries(stages.map(stage=>{const passed=members.filter(p=>p.progress?.[stage]?.done===true).length,known=members.filter(p=>p.progress?.[stage]?.known===true).length;return [stage,{done:valid&&passed===members.length,passed,known,total:members.length}];}));
  return {...raw,members,valid,name:members.map(p=>firstName(p.name)).join(' - '),channels:[...new Set(members.map(p=>p.channel).filter(Boolean))],progress,completed:stages.filter(s=>progress[s].done).length};
 }
 function validate(members,roster,groups,editingId){
  if(!Array.isArray(members)||![2,3].includes(members.length))return 'Mỗi nhóm cần đúng 2 PG, hoặc 3 PG khi danh sách của Trainer có số lẻ.';
  const codes=members.map(code);if(codes.some(x=>!x)||new Set(codes).size!==codes.length)return 'Không được chọn trùng PG trong nhóm.';
  const available=new Set(roster.map(p=>p.code));if(codes.some(c=>!available.has(c)))return 'Chỉ được ghép PG trong danh sách Master do Trainer này phụ trách.';
  if(groups.some(g=>g.id!==editingId&&(g.members||[]).some(c=>codes.includes(code(c)))))return 'Một PG chỉ được thuộc một nhóm trong chiến dịch. Hãy tải lại danh sách.';
  if(codes.length===3&&(roster.length%2===0||groups.some(g=>g.id!==editingId&&g.members?.length===3)))return 'Chỉ tạo một nhóm 3 khi tổng PG của Trainer là số lẻ.';
  return '';
 }
 function summary(groups){return {total:groups.length,stages:stages.map(s=>groups.filter(g=>g.progress[s].done).length),completed:groups.filter(g=>g.completed===5).length,invalid:groups.filter(g=>!g.valid).length};}
 return {stages,code,norm,flag,firstName,roster,group,validate,summary};
})();
