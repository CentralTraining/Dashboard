-- New, initially empty storage for Find Master pairing. No existing tables/data are changed.
begin;
create table public.pgsm_pair_groups (
  campaign_id text not null,
  trainer_id text not null,
  version bigint not null default 1 check (version >= 1),
  groups jsonb not null default '[]'::jsonb check (jsonb_typeof(groups) = 'array' and jsonb_array_length(groups) <= 500),
  updated_by text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (campaign_id, trainer_id)
);
alter table public.pgsm_pair_groups enable row level security;
revoke all on table public.pgsm_pair_groups from public, anon, authenticated;
grant select, insert, update, delete on table public.pgsm_pair_groups to service_role;
comment on table public.pgsm_pair_groups is 'Find Master groups; accessible only through the authenticated, trainer-scoped pairing Edge Function.';
commit;
