from pathlib import Path
import json,hashlib,shutil
p=Path(__file__).parent;src=p.parent
data=(src/'index.html').read_bytes();assert hashlib.sha256(data).hexdigest()=='6e05e58cb432d6b69942e7bd338b767622aa889de03cbc86bf40d9b61f6e7462'
assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()=='837abf7655b02d32b276bcd9764b098ccc3aa35b'
base=(src/'before.html').read_bytes();assert hashlib.sha256(base).hexdigest()=='1561a72e58c9487aea385ba34da5e5eadcdc4cfa0b32fb8d809639ff02d610f2'
name='Dashboard-Chinh-2026-10-29-Target-Truyen-Thong-A-PG.html'
for n in ['index.html',name]:(p/n).write_bytes(data)
for n in ['model.js','media-target-a.js','style.css']:shutil.copyfile(src/n,p/n)
m=json.loads((src/'manifest.json').read_text());m.pop('source_zip',None);m.pop('artifacts',None)
m.update({'scope':'Main','filename':name,'base_commit':'f8b6b1e941b794f683d0bf90fde2ccc6f34b667f','feature_test_commit':'27b761af239877862283d8bc3f96ce491a8a0718','html_identical_to_test':True,'main_changed':True,'test_changed':False})
(p/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
for n in ['check-ui.cjs','check-stale.cjs']:
 s=(src/n).read_text().replace("MOBILE_HTML='media-target-a-20261029/index.html'","MOBILE_HTML='media-target-a-20261029/main/index.html'").replace("require('../mobile-audit.cjs')","require('../../mobile-audit.cjs')").replace('https://centraltraining.github.io/Test/','https://centraltraining.github.io/Dashboard/')
 (p/n).write_text(s)
print(json.dumps(m))
