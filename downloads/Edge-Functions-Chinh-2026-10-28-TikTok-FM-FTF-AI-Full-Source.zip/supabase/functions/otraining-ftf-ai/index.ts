import { authenticate, AccessError, readDashboardValues } from './access.ts';
// Test-only, read-only FTF AI adapter. Every request requires a real Dashboard session.
// The gateway JWT alone never authorizes access. Trainers receive only their Target FTF region.
const CORS={'Access-Control-Allow-Origin':'https://centraltraining.github.io','Access-Control-Allow-Headers':'authorization,apikey,content-type','Access-Control-Allow-Methods':'POST,OPTIONS','Vary':'Origin'};
const json=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{...CORS,'Content-Type':'application/json'}});
const clean=v=>String(v??'').trim();
const id=v=>/^[1-9]\d{0,11}$/.test(clean(v));
const norm=v=>clean(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[Đđ]/g,'d').toLowerCase().replace(/[^a-z0-9]/g,'');
const record=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
function first(v){if(Array.isArray(v))return v[0];try{const a=JSON.parse(v);if(Array.isArray(a))return a[0];}catch{}return v;}
function normalizeAiDownload(data,campaignId,shopId='',allowed=null){
 if(!record(data)||!Array.isArray(data.mainSheetData)||!record(data.detailSheetData))throw Error('shape');
 const detail=data.detailSheetData;
 if(!Array.isArray(detail.allAttendees)||!record(detail.simulationStatusMap)||!record(detail.nameMap))throw Error('shape');
 const allShops=new Map(),shops=new Map();
 for(const raw of data.mainSheetData){
  if(!record(raw)||!id(raw.shop_id)||raw.campaign_id!=null&&clean(raw.campaign_id)!==campaignId)throw Error('shop');
  const key=clean(raw.shop_id),code=clean(raw.store_id_excel);
  if(allShops.has(key)&&allShops.get(key)!==code)throw Error('collision');
  allShops.set(key,code);
  if(norm(first(raw.vung))!=='mientrung')continue;
  if(allowed&&!allowed.ids.has(key)&&!allowed.codes.has(code))continue;
  if(!shops.has(key))shops.set(key,{shopId:key,shopCode:code,people:[]});
 }
 const pairs=new Set();let orphan=0;
 for(const attendee of detail.allAttendees){
  if(!record(attendee)||!id(attendee.shop_id)||!id(attendee.user_id))throw Error('attendee');
  const sid=clean(attendee.shop_id),uid=clean(attendee.user_id);
  if(!allShops.has(sid)){orphan++;continue;}
  const shop=shops.get(sid),pair=sid+':'+uid;
  if(!shop||pairs.has(pair))continue;
  pairs.add(pair);
  const value=detail.simulationStatusMap[uid],token=clean(value).toLowerCase();
  const status=token==='dat'?'dat':token==='chua_dat'?'chua_dat':value==null||token===''||token==='chua_lam'?'chua_lam':'unknown';
  shop.people.push({id:uid,name:clean(detail.nameMap[uid])||'ID '+uid,status,passed:status==='dat'});
 }
 if(orphan)throw Error('orphan');
 if(shopId&&!shops.has(shopId))return null;
 const selected=shopId?[shops.get(shopId)]:[...shops.values()];
 for(const shop of selected){
  shop.total=shop.people.length;shop.passed=shop.people.filter(p=>p.status==='dat').length;
  shop.failed=shop.people.filter(p=>p.status==='chua_dat').length;
  shop.notStarted=shop.people.filter(p=>p.status==='chua_lam').length;
  shop.unknown=shop.people.filter(p=>p.status==='unknown').length;
 }
 return selected;
}
Deno.serve(async req=>{
 const origin=req.headers.get('origin');
 if(origin&&origin!=='https://centraltraining.github.io')return json({error:'Nguồn truy cập không hợp lệ.'},403);
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers:CORS});
 if(req.method!=='POST')return json({error:'Chỉ hỗ trợ POST.'},405);
 if(Number(req.headers.get('content-length')||0)>1600)return json({error:'Yêu cầu quá dài.'},413);
 let body;try{const raw=await req.text();if(raw.length>1600)return json({error:'Yêu cầu quá dài.'},413);body=JSON.parse(raw);}catch{return json({error:'Yêu cầu không hợp lệ.'},400);}
 if(!record(body)||body.type!=='ftfai'||!id(body.campaignId)||body.shopId!==undefined&&!id(body.shopId)||!/^\d{4}-(0[1-9]|1[0-2])$/.test(body.month||''))return json({error:'Tháng hoặc ID chiến dịch/shop không hợp lệ.'},400);
 let principal,allowed=null;
 try{
  principal=await authenticate(body.dashboardToken);
  const values=await readDashboardValues(['campaigns']);
  const campaigns=(values.campaigns||[]).filter(c=>c.group==='doitac'&&(c.subtype||'ftf')==='ftf'&&c.month===body.month&&clean(c.otrId)===clean(body.campaignId));
  if(campaigns.length!==1)return json({error:'Chiến dịch FTF chưa được Admin cấu hình cho tháng đang xem.'},403);
  if(principal.role!=='admin'){
   if(principal.role!=='trainer'||!norm(principal.region))return json({error:'Không có quyền xem dữ liệu FTF.'},403);
   const campaign=campaigns[0],targets=await readDashboardValues(['ftfTargetRows:'+campaign.id]);
   const rows=targets['ftfTargetRows:'+campaign.id];
   if(!Array.isArray(rows))return json({error:'Chưa có Target FTF để kiểm tra quyền theo khu vực.'},409);
   const mine=rows.filter(row=>{
    const trainer=principal.trainers.find(t=>String(t.id)===String(row.trainerId));
    return norm(trainer?.region||row.region)===norm(principal.region);
   });
   allowed={ids:new Set(mine.map(r=>clean(r.storeId)).filter(Boolean)),codes:new Set(mine.map(r=>clean(r.storeId)).filter(Boolean))};
  }
 }catch(error){return json({error:error instanceof AccessError?error.message:'Không kiểm tra được quyền FTF. Hãy thử lại.'},error instanceof AccessError?error.status:503);}
 const campaignId=clean(body.campaignId),shopId=clean(body.shopId),userInfo=Deno.env.get('OTRAINING_USER_INFO');
 // Forward the existing server credential without decoding or returning it.
 // The upstream service-account request is made only after Dashboard authentication
 // and campaign authorization; a Trainer's response is filtered by Admin-owned Target rows.
 if(!userInfo)return json({error:'Chưa sẵn sàng kết nối otraining.'},503);
 let data;
 try{
  const response=await fetch('https://otraining.io.vn/api/qrcode/f2f-visits/download-all',{
   method:'POST',redirect:'error',headers:{'Content-Type':'application/json','Accept':'application/json','Origin':'https://otraining.io.vn','Referer':'https://otraining.io.vn/doitac_f2f.html?id='+campaignId,'x-user-info':userInfo},
   body:JSON.stringify({campaignId,userId:458,userType:'Leader',userArea:'Mien Trung',status:null,shopName:null,areaFilter:null,vungFilter:'Mien Trung'}),signal:AbortSignal.timeout(40000),
  });
  if(!response.ok)return json({error:'Chưa lấy được Tư vấn mẫu AI từ otraining (HTTP '+response.status+'). Dữ liệu đã lưu được giữ nguyên.'},502);
  data=await response.json();
 }catch{return json({error:'Chưa đọc được Tư vấn mẫu AI. Hãy thử lại; dữ liệu đã lưu được giữ nguyên.'},502);}
 let shops;try{shops=normalizeAiDownload(data,campaignId,shopId,allowed);}catch{return json({error:'Nguồn Tư vấn mẫu AI chưa đủ dữ liệu hoặc chưa khớp chiến dịch/shop. Dữ liệu đã lưu được giữ nguyên.'},502);}
 if(shops===null)return json({error:'Shop không thuộc chiến dịch/khu vực đang xem.'},404);
 return json({ok:true,campaignId,source:'simulationStatusMap',readAt:new Date().toISOString(),shops});
});
