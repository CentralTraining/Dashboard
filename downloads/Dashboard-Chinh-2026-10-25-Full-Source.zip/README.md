# Dashboard chính — 25/10/2026

Website: https://centraltraining.github.io/Dashboard/

## Nội dung triển khai

- `index.html` là đúng HTML đã kiểm thử và phát hành trên Test, commit `94a6535aa9dd0e5ee041912eb79639183b31d5ec`.
- Gồm menu mới, giao diện gọn trên desktop/mobile, các chỉ số Follow/View/Like/Share và nhịp đăng video.
- `terms.html` và `privacy.html` được chuyển sang đường dẫn dashboard chính; giữ đơn vị quản lý và liên hệ đã cung cấp.
- Nâng function `trainer-channel` từ phiên bản 5 lên 6 để hỗ trợ follower, giữ mốc 01/10/2026, phân quyền khu vực và số liệu chưa xác định.
- Không đổi Secrets, function Test, code gửi KPI, workflow, trigger hoặc nhánh sổ gửi.

## Dữ liệu TikTok từ Test

Khi người dùng đã xác thực mở Xây kênh, function chính kiểm tra từng Trainer trong phạm vi được phép. Nếu bản chính chưa có bản ghi và hai function đang dùng cùng Client Key TikTok, bản ghi kênh trên Test được đọc ở phía máy chủ, mã hóa lại theo khóa bản ghi chính rồi lưu bằng cơ chế kiểm tra phiên bản. Bản ghi đã có trên chính luôn được giữ. Không sửa hay xóa nguồn Test.

Giữ nguyên trang đã gán, token còn trong bản ghi, snapshot, mốc follower và lịch sử. Không khẳng định token đã được TikTok chấp nhận chỉ từ việc chuyển dữ liệu. Nếu cấu hình hai ứng dụng khác nhau, không sao chép token; cần kết nối đúng ứng dụng trên bản chính.

Các thao tác chưa đăng nhập không thể chuyển dữ liệu. Trainer không thể chuyển/xem kênh ngoài khu vực được phép. Token và định danh tài khoản TikTok không xuất ra trình duyệt.

## Cấu hình TikTok bên ngoài

Website chính: `https://centraltraining.github.io/Dashboard/`

Redirect URI chính: `https://qruxqlsbhyhwiqjdkyyc.supabase.co/functions/v1/trainer-channel/oauth/callback`

Function chính tiếp tục đọc `TIKTOK_CLIENT_KEY` và `TIKTOK_CLIENT_SECRET` từ Supabase, không nhúng giá trị vào HTML/mã nguồn. Hồ sơ TikTok gần nhất người dùng cung cấp đang In review. Cần khai báo/được chấp nhận URL chính và các quyền cần thiết trong TikTok Developers; triển khai website không thay thế việc xét duyệt của TikTok.

Mở dashboard chính, đăng nhập Admin, vào Mở rộng → Xây kênh để tải dữ liệu theo quyền. Chỉ xác nhận các kênh đã kết nối/đồng bộ dựa trên trạng thái thực tế; không coi 13 bản ghi đã gán là 13 lần cấp quyền thành công.

## Kiểm tra

- HTML giống hệt bản Test đã duyệt.
- UI ở 320×844, 390×844, 1024×600, 1280×500, 1366×768, 1440×900, 1920×1080.
- Backend: quyền khu vực, xác thực, mã hóa, token không xuất ra overview, quyền follower tùy chọn, lỗi TikTok không xóa snapshot, không tạo mốc lịch sử giả.
- Chuyển dữ liệu: cùng ứng dụng, mã hóa lại theo bản ghi đích, không ghi đè, không sửa nguồn Test, không vượt phạm vi và xử lý hai lượt đọc đồng thời.
- Kiểm tra endpoint thực tế: status và callback đúng, chặn mọi thao tác dữ liệu khi không có phiên đăng nhập, chặn origin không hợp lệ.
- Mọi kiểm thử số liệu dùng dữ liệu giả lập. Chưa xác nhận đủ 13 kênh TikTok hoạt động bằng tài khoản thực của người dùng.

Gói chứa HTML đầy đủ, trang chính sách, bốn file function và cấu hình. Không chứa Secrets hoặc dữ liệu riêng của Trainer.
