from pathlib import Path
import hashlib,json,shutil

r=Path(__file__).parent
source=r.parent
before=Path('/workspace/dashboard-channel/media-export-20261029/main/index.html').read_bytes()
assert hashlib.sha256(before).hexdigest()=='08692967a2ba1e7846c19ca59f85082fe8206f6b9b998ca4c4f1ca9c07ea6667'
(r/'before.html').write_bytes(before)
b=(source/'index.html').read_bytes()
assert hashlib.sha256(b).hexdigest()=='5e8ddea76126421bfc2dd56721950c7837bbce2e751258a087feecd0015f729d'
name='Dashboard-Chinh-2026-11-01-FindMaster-Kiem-Tra-Cap-PGs-HR.html'
for n in ['index.html',name]:(r/n).write_bytes(b)
shutil.copytree(source/'function',r/'function',dirs_exist_ok=True)
f=r/'function/index.ts'
s=f.read_text()
assert s.count("const ENVIRONMENT='test';")==1
s=s.replace("const ENVIRONMENT='test';","const ENVIRONMENT='main';").replace("// Test-only writes. A future Main promotion must use the literal 'main'.","// Main workflow writes only; Test workflow records and legacy groups remain unchanged.")
f.write_text(s)
for n in ['pairs-ui.js','pairs.css','workflow.css','eligibility.css']:shutil.copyfile(source/n,r/n)
backend=(source/'check-backend.cjs').read_text()
backend=backend.replace("'test'","'__ENV__'").replace("'main'","'test'").replace("'__ENV__'","'main'")
backend=backend.replace("'test|","'__KEY__|").replace("'main|","'test|").replace("'__KEY__|","'main|")
backend=backend.replace('Only Test namespace changes','Only Main namespace changes').replace('Test namespace isolated from Main and legacy','Main namespace isolated from Test and legacy').replace('A Main workflow record is never read or changed by Test','A Test workflow record is never read or changed by Main')
(r/'check-backend.cjs').write_text(backend)
s=(source/'check-eligibility.cjs').read_text().replace("'test'","'main'").replace("'test|","'main|")
(r/'check-eligibility.cjs').write_text(s)
for n in ['check-ui.cjs','check-hr-ui.cjs']:
 s=(source/n).read_text().replace("MOBILE_HTML='pair-hr-20261101/index.html'","MOBILE_HTML='pair-hr-20261101/main/index.html'").replace("require('../mobile-audit.cjs')","require('../../mobile-audit.cjs')").replace('https://centraltraining.github.io/Test/','https://centraltraining.github.io/Dashboard/').replace('pgsm-pairs-test','pgsm-pairs').replace("'test|","'main|")
 (r/n).write_text(s)
(r/'check-live.py').write_text((source/'check-live.py').read_text().replace('pgsm-pairs-test','pgsm-pairs'))
m={'scope':'Main','date':'2026-11-01','filename':name,'base_commit':'ae468a424ff61c07a623e84c8c3601dd5b6bdbbc','feature_test_commit':'a0c64d8c456e70628bbccec94b9db0c1f69f7cfc','bytes':len(b),'characters':len(b.decode()),'sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'function':'pgsm-pairs','environment':'main','html_identical_to_test':True,'schema_changed':False,'secrets_changed':False,'business_data_changed':False}
(r/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
files=[{'name':f.name,'content':f.read_text()} for f in sorted((r/'function').iterdir()) if f.is_file()]
(r/'deploy-files.json').write_text(json.dumps(files,ensure_ascii=False))
print(json.dumps(m))
